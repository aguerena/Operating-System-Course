int Seminit(int idsem, int val);
int Semwait(int idsem);
int Semsignal(int idsem);
